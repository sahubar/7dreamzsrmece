<?php

$server = "localhost";
$user = "root";
$password = "";
$db = "aadhar";

$con = mysqli_connect($server,$user,$password,$db);



?>

