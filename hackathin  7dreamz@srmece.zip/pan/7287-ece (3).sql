-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2021 at 04:22 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ece`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `sno` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `wallet` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`sno`, `username`, `email`, `mobile`, `password`, `cpassword`, `date`, `wallet`) VALUES
(1, 'admin', 'admin@gmail.com', '07397639193', '$2y$10$q6Honi.KS05gmtNrAnWoF.WBESAfAWHBHazxxXNg2NBDCouiDiumO', '$2y$10$xAis7uiwXkEc.6mlqc2hIe49Rvuz.wJ3Up9D57LyTsDnFGHKumq.2', '2021-08-27', '0');

-- --------------------------------------------------------

--
-- Table structure for table `annauniversity`
--

CREATE TABLE `annauniversity` (
  `sno` int(11) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `mark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `annauniversity`
--

INSERT INTO `annauniversity` (`sno`, `reg`, `semester`, `subject`, `mark`) VALUES
(1, '814719106050', '2', 'engineering Mathematics-2', 'o+'),
(3, '814719106055', '1', 'EC3551-Discrete-Time Signal Processing', 'o+');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `sno` int(11) NOT NULL,
  `detail` varchar(10000) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`sno`, `detail`, `date`) VALUES
(1, 'ccc', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `sno` int(11) NOT NULL,
  `benificiary` varchar(100) NOT NULL,
  `anum` varchar(100) NOT NULL,
  `ifsc` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`sno`, `benificiary`, `anum`, `ifsc`, `branch`) VALUES
(1, 'SRM TRP ENGINEERING COLLEGE', '1478956232145782', 'CUB000214', 'THILLAI NAGAR'),
(2, 'SRM TRP TRANSPORT LTD', '1478956232145782', 'CUB000214', 'THILLAI NAGAR'),
(4, '7DREAMZ', '1234567890', 'SBIN0010412', 'branch'),
(6, '7DREAMZsd', '1234567890', 'ESFB0001028', 'branch'),
(7, 'lab', '78945928298', 'sbim001', 'branch'),
(8, 'sivasadhik class fees', '78945928298', 'sbim001', 'branch'),
(9, 'saf', '123456789098765432', 'erycvhcfhy', 'branch');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `sno` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `feesname` varchar(100) NOT NULL,
  `reference` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`sno`, `email`, `reg`, `username`, `feesname`, `reference`) VALUES
(8, 'sahubarsadhik051@gmail.com', '814719106050', 'Sadhik', 'SRM TRP TRANSPORT LTD', '12erefe'),
(9, 'sahubarsadhik051@gmail.com', '814719106050', 'Sadhik', '7DREAMZ', '12erefe'),
(10, 'sahubarsadhik051@gmail.com', '8147191c06050', 'Sadhik', 'lab', '12erefe'),
(11, 'sahubarsadhik051@gmail.com', '814719106050', 'Sadhik', 'lab', '12erefe'),
(12, 'sahubarsadhik051@gmail.com', '814719106050', 'Sadhik', 'sivasadhik class fees', '12erefe');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `sno` int(11) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`sno`, `bookname`, `author`, `department`) VALUES
(1, 'electronics', 'xxxxx', 'ece'),
(3, 'srm', 'yyyy', 'ece');

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `sno` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `txnid` varchar(100) NOT NULL,
  `productinfo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `createat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`sno`, `firstname`, `amount`, `txnid`, `productinfo`, `email`, `status`, `createat`) VALUES
(1, 'Sadhik', '1000.00', 'ed1024612aca684a6db4', 'Sadhik', 'sahubarsadhik051@gmail.com', 'success', '2021-10-13 10:16:40'),
(2, 'Sadhik', '10000.00', '6cd307d980d212c6c910', 'Sadhik', 'sahubarsadhik051@gmail.com', 'success', '2021-10-13 12:55:23');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendence`
--

CREATE TABLE `student_attendence` (
  `ID` int(11) NOT NULL,
  `STUDENTID` varchar(1000) NOT NULL,
  `ATTENDENCE` varchar(100) NOT NULL,
  `TIMEIN` varchar(1000) NOT NULL,
  `DATE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_attendence`
--

INSERT INTO `student_attendence` (`ID`, `STUDENTID`, `ATTENDENCE`, `TIMEIN`, `DATE`) VALUES
(1, '814719106055', 'Present', '12:49:02', '2021-10-13'),
(2, '814719106050', 'Present', '13:47:17', '2021-10-13'),
(3, '814719106055', 'Present', '13:47:23', '2021-10-13'),
(4, '814719106050', 'Present', '11:45:20', '2021-10-21'),
(5, '814719106050', 'Present', '11:45:24', '2021-10-21');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `sno` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `wallet` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`sno`, `username`, `email`, `mobile`, `reg`, `password`, `cpassword`, `date`, `wallet`) VALUES
(5, 'Sadhik', 'sahubarsadhik051@gmail.com', '1234567890', '814719106050', '$2y$10$nTRyeHFDK9Bu7FjzEXDKWe6QIjbo1D81iotX.AXGbaK2ZJNFv4Feq', '$2y$10$t.FACxJ7/bi36A8BmX3Td..gQltjUjP/fGZhfYOnlx1e1PgQL8dPe', '2021-08-24', '44150'),
(8, 'siva', 'sivakid592001@gmail.com', '8637460075', '814719106055', '$2y$10$HGNv/XW2pxr3VQBO2heuj.bru.e7TWPafLn/O2M44y4DKwCEQVJBC', '$2y$10$5er7neYStPQItaoX1INxHuTVDgrDAWc27ZyuBDwskmeFN3peDsf5m', '2021-10-11', '17050');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sno` int(11) NOT NULL,
  `subject1` varchar(100) NOT NULL,
  `subject2` varchar(100) NOT NULL,
  `subject3` varchar(100) NOT NULL,
  `subject4` varchar(100) NOT NULL,
  `subject5` varchar(100) NOT NULL,
  `subject6` varchar(100) NOT NULL,
  `link1` varchar(100) NOT NULL,
  `link2` varchar(100) NOT NULL,
  `link3` varchar(100) NOT NULL,
  `link4` varchar(100) NOT NULL,
  `link5` varchar(100) NOT NULL,
  `link6` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sno`, `subject1`, `subject2`, `subject3`, `subject4`, `subject5`, `subject6`, `link1`, `link2`, `link3`, `link4`, `link5`, `link6`) VALUES
(1, 'EC3551-Digital communications', 'EC3551-Discrete-Time Signal Processing', 'Computer Architecture and Organization', 'Communication NetwoCommunication Network', 'Total Quality Management', 'Basic of Biomedical Instrumentation', 'www.google.in', 'www.sadhik.in', 'www.sadhik.in', 'www.sadhik.in', 'www.sadhik.in', 'www.sadhik.in');

-- --------------------------------------------------------

--
-- Table structure for table `subject1`
--

CREATE TABLE `subject1` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject1`
--

INSERT INTO `subject1` (`sno`, `title`, `image`) VALUES
(6, 'title', '2472-Mini Project PPT.pptx'),
(9, 'UNIT TEST QUESTION PAPER ', '3949-Mini Project PPT.pptx'),
(10, 'unit test 1qp', '8941-2472-Mini Project PPT.pptx');

-- --------------------------------------------------------

--
-- Table structure for table `subject2`
--

CREATE TABLE `subject2` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject2`
--

INSERT INTO `subject2` (`sno`, `title`, `image`) VALUES
(1, 'mcoin', '9582-RENTAL DEED (1).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `subject3`
--

CREATE TABLE `subject3` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject3`
--

INSERT INTO `subject3` (`sno`, `title`, `image`) VALUES
(1, 'sadhik', '7525-IMG-20210825-WA0057.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `subject4`
--

CREATE TABLE `subject4` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject4`
--

INSERT INTO `subject4` (`sno`, `title`, `image`) VALUES
(1, 'mcoin', '4923-srm.sql');

-- --------------------------------------------------------

--
-- Table structure for table `subject5`
--

CREATE TABLE `subject5` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject5`
--

INSERT INTO `subject5` (`sno`, `title`, `image`) VALUES
(1, 'sadhik', '5690-RENTAL DEED (1).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `subject6`
--

CREATE TABLE `subject6` (
  `sno` int(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject6`
--

INSERT INTO `subject6` (`sno`, `title`, `image`) VALUES
(1, 'mcoin', '6959-RENTAL DEED (1).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `sno` int(11) NOT NULL,
  `remail` varchar(1000) NOT NULL,
  `coin` varchar(100) NOT NULL,
  `semail` varchar(1000) NOT NULL,
  `createat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`sno`, `remail`, `coin`, `semail`, `createat`) VALUES
(1, 'sivakid592001@gmail.com', '50', 'sahubarsadhik051@gmail.com', '2021-10-11 13:10:35'),
(2, 'sivakid592001@gmail.com', '2000', 'sahubarsadhik051@gmail.com', '2021-10-13 10:17:36'),
(3, 'sivakid592001@gmail.com', '15000', 'sahubarsadhik051@gmail.com', '2021-10-13 12:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `usubject1`
--

CREATE TABLE `usubject1` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject1`
--

INSERT INTO `usubject1` (`sno`, `reg`, `title`, `image`) VALUES
(5, '814719106050', 'YTOL', '4674-ece 2.docx'),
(6, '814719106050', 'hgdsg', '4896-ECEB.docx');

-- --------------------------------------------------------

--
-- Table structure for table `usubject2`
--

CREATE TABLE `usubject2` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject2`
--

INSERT INTO `usubject2` (`sno`, `reg`, `title`, `image`) VALUES
(1, '814719106050', 'der', '2479-Gold Navy Simple Boarding Pass Invitation.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `usubject3`
--

CREATE TABLE `usubject3` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject3`
--

INSERT INTO `usubject3` (`sno`, `reg`, `title`, `image`) VALUES
(1, '814719106050', 'p', '1135-Gold Navy Simple Boarding Pass Invitation.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `usubject4`
--

CREATE TABLE `usubject4` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject4`
--

INSERT INTO `usubject4` (`sno`, `reg`, `title`, `image`) VALUES
(1, '814719106050', '[', '7776-Gold Navy Simple Boarding Pass Invitation.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `usubject5`
--

CREATE TABLE `usubject5` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject5`
--

INSERT INTO `usubject5` (`sno`, `reg`, `title`, `image`) VALUES
(1, '814719106050', '[', '1502-Gold Navy Simple Boarding Pass Invitation.png');

-- --------------------------------------------------------

--
-- Table structure for table `usubject6`
--

CREATE TABLE `usubject6` (
  `sno` int(100) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usubject6`
--

INSERT INTO `usubject6` (`sno`, `reg`, `title`, `image`) VALUES
(1, '814719106050', ']4', '4893-Gold Navy Simple Boarding Pass Invitation.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `webportal`
--

CREATE TABLE `webportal` (
  `sno` int(11) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  `mark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webportal`
--

INSERT INTO `webportal` (`sno`, `reg`, `subject`, `period`, `mark`) VALUES
(2, '814719106050', 'EC3551-Discrete-Time Signal Processing', '12', '89'),
(3, '814719106050', 'EC3551-Digital communications', '12', '89'),
(4, '814719106050', 'Coputer Architecture and Organization', '12', '89'),
(5, '814719106050', 'Communication NetwoCommunication Network', '12', '89'),
(6, '814719106050', 'Total Quality Management', '12', '89'),
(8, '814719106050', 'Basic of Biomedical Instrumentation', '12', '89'),
(9, '814719106055', 'EC3551-Digital communications', '100', '99'),
(10, '814719106055', 'EC3551-Discrete-Time Signal Processing', '100', '99'),
(11, '814719106055', 'Coputer Architecture and Organization', '100', '99'),
(12, '814719106055', 'Communication NetwoCommunication Network', '100', '99'),
(13, '814719106055', 'Basic of Biomedical Instrumentation', '100', '99'),
(14, '814719106055', 'Total Quality Management', '100', '99'),
(15, '814719106055', 'Coputer Architecture and Organization', '100', '100');

-- --------------------------------------------------------

--
-- Table structure for table `webportal2`
--

CREATE TABLE `webportal2` (
  `sno` int(11) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  `mark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webportal2`
--

INSERT INTO `webportal2` (`sno`, `reg`, `subject`, `period`, `mark`) VALUES
(1, '814719106050', 'EC3551-Digital communications', '100', '89'),
(2, '814719106055', 'EC3551-Digital communications', '100', '99');

-- --------------------------------------------------------

--
-- Table structure for table `webportal3`
--

CREATE TABLE `webportal3` (
  `sno` int(11) NOT NULL,
  `reg` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  `mark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `webportal3`
--

INSERT INTO `webportal3` (`sno`, `reg`, `subject`, `period`, `mark`) VALUES
(1, '814719106050', 'EC3551-Digital communications', '100', '99'),
(2, '814719106055', 'EC3551-Digital communications', '100', '99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `annauniversity`
--
ALTER TABLE `annauniversity`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `pay`
--
ALTER TABLE `pay`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `student_attendence`
--
ALTER TABLE `student_attendence`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject1`
--
ALTER TABLE `subject1`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject2`
--
ALTER TABLE `subject2`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject3`
--
ALTER TABLE `subject3`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject4`
--
ALTER TABLE `subject4`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject5`
--
ALTER TABLE `subject5`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `subject6`
--
ALTER TABLE `subject6`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject1`
--
ALTER TABLE `usubject1`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject2`
--
ALTER TABLE `usubject2`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject3`
--
ALTER TABLE `usubject3`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject4`
--
ALTER TABLE `usubject4`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject5`
--
ALTER TABLE `usubject5`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `usubject6`
--
ALTER TABLE `usubject6`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `webportal`
--
ALTER TABLE `webportal`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `webportal2`
--
ALTER TABLE `webportal2`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `webportal3`
--
ALTER TABLE `webportal3`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `annauniversity`
--
ALTER TABLE `annauniversity`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `library`
--
ALTER TABLE `library`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pay`
--
ALTER TABLE `pay`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_attendence`
--
ALTER TABLE `student_attendence`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_login`
--
ALTER TABLE `student_login`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subject1`
--
ALTER TABLE `subject1`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `subject2`
--
ALTER TABLE `subject2`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subject3`
--
ALTER TABLE `subject3`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subject4`
--
ALTER TABLE `subject4`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subject5`
--
ALTER TABLE `subject5`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subject6`
--
ALTER TABLE `subject6`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transfer`
--
ALTER TABLE `transfer`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usubject1`
--
ALTER TABLE `usubject1`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usubject2`
--
ALTER TABLE `usubject2`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usubject3`
--
ALTER TABLE `usubject3`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usubject4`
--
ALTER TABLE `usubject4`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usubject5`
--
ALTER TABLE `usubject5`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usubject6`
--
ALTER TABLE `usubject6`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `webportal`
--
ALTER TABLE `webportal`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `webportal2`
--
ALTER TABLE `webportal2`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `webportal3`
--
ALTER TABLE `webportal3`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
