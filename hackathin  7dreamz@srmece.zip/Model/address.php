<?php
	ini_set("memory_limit","256M"); 
	//this sets it unlimited
	ini_set("max_execution_time",0);
	include('../dbcon.php');
	session_start();

	if(isset($_POST['submit']) && ($_POST['submit'] == 'Update'))
	{	
		
		$email = trim($_POST['email']);
		$address = trim($_POST['address']);
      
		
		
	
		
		$log_sql = "Update  `login_details` set address='$address' where email='$email'";
		
		$log_qr = mysqli_query($con,$log_sql);       
        if($log_qr == TRUE)
        {   
			$_SESSION['success']="Status  Updated Successfully";
			echo '<script type="text/javascript">
			window.location.href="../view.php";</script>"';
		}
		else
		{
		$_SESSION['error']="Status  Updated Failed";
			echo '<script type="text/javascript">window.location.href="../viewcoin.php";</script>';
		}
		
	}
?>