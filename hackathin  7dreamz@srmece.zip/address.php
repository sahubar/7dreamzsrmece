<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    $wallet = $_SESSION["wallet"];
    $email = $_SESSION["email"];
    $date = $_SESSION["date"];
        $mobile = $_SESSION["mobile"];
        $reg = $_SESSION["reg"];



    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Skydash Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/feather/feather.css">
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" type="text/css" href="js/select.dataTables.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
<body>
  <?php include_once 'slidebar.php';  ?>
      <!-- partial -->
          
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Enter New Address</h4>
                  <p class="card-description">
                  </p>
                  <form method="post" enctype="multipart/form-data">

    <input type="text" value="<?php echo($email)?>" name="title">

  <div>
    <label>Pan Number</label>
     <div class="form-group">
  <div class="form-line">
    <input type="text" class="form-control" name="address" placeholder="Enter Your address">
  </div>
</div>
</div>
  <br>
  <div> 
      <label>File Upload</label>
    <input type="File" class="btn btn-primary m-t-15 waves-effect"  name="file">
  </div>
  <br>
    <center><input type="submit" class="btn btn-primary m-t-15 waves-effect" name="submit"></center>
 
</form>
                </div>
              </div>
            </div>
            

 <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body" id="bank">
                  <h4 class="card-title">address Details</h4>
                  <p class="card-description">
                  </p>
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Current Address                    </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                         <?php
                    include('dbcon.php');
                    $sql=mysqli_query($con, "select * from login_details");
                    while($row=mysqli_fetch_array($sql))
                    { ?>
                          <tr>
                            <td><?=$row['address'];?></td>
                           

 
                            <?php } ?>    
                                               
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
           

  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="js/dataTables.select.min.js"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/Chart.roundedBarCharts.js"></script>
  <!-- End custom js for this page-->
</body>

</html>

<?php 
include_once 'dbcon.php';
#connection string
 
if (isset($_POST["submit"]))
 {
     #retrieve file title
        $title = $_POST["title"];
        $address = $_POST["address"];
     
    #file name with a random number so that similar dont get replaced
     $pname = rand(1000,10000)."-".$_FILES["file"]["name"];
 
    #temporary file name to store file
    $tname = $_FILES["file"]["tmp_name"];
   
     #upload directory path
$uploads_dir = 'pan';
    #TO move the uploaded file to specific location
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);
 $log_sql = "Update  `login_details` set address='$address' where email='$email'";
 $log_qr = mysqli_query($con,$log_sql);       
    

 $sql = "Update  `proof` set image='$pname' where title='$title'";


    #sql query to insert into database
    //$sql = "INSERT into proof(title,image) VALUES('$title','$pname')";
 
    if(mysqli_query($con,$sql)){
 
    echo '<script type="text/javascript">window.location.href="view.php";</script>';
    }
    else{
        echo "Error";
    }
}
 
 
?>
